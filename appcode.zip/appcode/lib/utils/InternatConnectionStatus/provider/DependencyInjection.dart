// import 'package:get/get.dart';
// import 'package:kameti_app/utils/InternatConnectionStatus/provider/InternatConnectionProvider.dart';

// class DependencyInjection {
//   static void init() {
//     Get.put(NetworkProvider(), permanent: true);
//   }
// }
